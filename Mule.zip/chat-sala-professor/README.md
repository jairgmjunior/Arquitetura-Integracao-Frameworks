# Chat sala do Professor

## Serviço para visualizar conversas da sala de um respectivo professor:

* MYSQL database

- Instruções
------------------------------------------------------------------------------------------------------------------------------------
* Create database 

CREATE TABLE `chat` (
   `id` int NOT NULL,
   `cpf` varchar(45) DEFAULT NULL,
   `mensagem` varchar(45) DEFAULT NULL,
   `data_hora_mensagem` varchar(45) DEFAULT NULL,
   PRIMARY KEY (`id`)
 )

insert into chat (id,cpf,mensagem, data_hora_mensagem) values (1,'808.159.570-84', 'Ola bom dia', '27/06/2020 09:58');
insert into chat (id,cpf,mensagem, data_hora_mensagem) values (2,'848.142.240-10', 'Bom dia pessoal, tudo bem?', '27/06/2020 09:59');
insert into chat (id,cpf,mensagem, data_hora_mensagem) values (3,'849.919.060-08', 'Sim, o que vamos ver hoje?', '27/06/2020 10:02');

-------------------------------------------------------------------------------------------------------------------------------------

ENDPOINT

http://localhost:8081/professor/808.159.570-84
