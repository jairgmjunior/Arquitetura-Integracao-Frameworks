**************************************
restaurar bancos postgres 
- integrações_input.tar
- integrações_output.tar

--------------------------------------

importar no Spoon
- integracao_input_output.ktr
- configurar o step de input e output pra conexão.

